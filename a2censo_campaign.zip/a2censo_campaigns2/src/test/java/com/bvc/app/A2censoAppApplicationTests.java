package com.bvc.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class A2censoAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
