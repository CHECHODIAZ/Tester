package com.bvc.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class A2censoAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(A2censoAppApplication.class, args);
	}

}
